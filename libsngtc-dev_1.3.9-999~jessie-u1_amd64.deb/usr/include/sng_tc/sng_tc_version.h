#ifndef __SNGTC_VERSION__
#define __SNGTC_VERSION__

#define SNGTC_VERSION(a,b,c,d) (((a) << 24) + ((b) << 16) + ((c) << 8) + d)
#define SNGTC_VERSION_CODE SNGTC_VERSION(1,3,9,0)
#define SNGTC_VERSION_STR "1.3.9.0"
#define SNGTC_GIT_REV "23a0059"

#endif
